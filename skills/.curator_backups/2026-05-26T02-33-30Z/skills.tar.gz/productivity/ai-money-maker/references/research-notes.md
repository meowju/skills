# AI副业研究数据（2024-2025）

> 本文件记录 Run 2 研究过程中发现的真实数据点，供后续迭代使用。

---

## 数据源

| 来源 | 类型 | 可用性 |
|------|------|--------|
| Hacker News Algolia API | 实时搜索 | `https://hn.algolia.com/api/v1/search?query=...&tags=story&hitsPerPage=10` |
| Wikipedia REST API | 稳定 | `https://en.wikipedia.org/api/rest_v1/page/summary/<term>` |
| Gumroad 公开数据 | 公开但需认证 | API 需要 Bearer token |
| Indie Hackers | 社区报告 | 公开，搜索可用 |
| ProductHunt API | 需认证 | `https://api.producthunt.com/v1/posts` |

---

## AI Side Hustle 研究关键词

```
AI side hustle income 2024
ChatGPT freelancer earnings 2024
Midjourney income report 2024
AI prompt engineer salary side hustle
AI content creation income 2024
making money AI tools income report
```

## 平台特定研究

### 中文平台数据
- 小红书：1000粉接广告，200-2000元/条
- 公众号：5000粉以上广告收入稳定
- 知乎：5000粉开专栏付费文章
- B站：1万播放约 $3-8，粉丝粘性高
- 知识星球：100人 ≈ 1-6万/年；500人 ≈ 5-30万/年

### 英文平台数据
- Gumroad：AI模板前10%创作者月入 $3,000+，中位数 ~$400
- Fiverr：新手单次 $25-300，稳定后 $75-150/单
- Upwork：项目制 $200-2000，有作品集后 $600+/项目
- YouTube AdSense：10万播放 ≈ $300-500

---

## HN 发现

搜索 "AI side hustle income" 返回的标题：
- "The AI Side Hustle Revolution: Turning Niche Ideas into Income"（高度相关）

---

## Micro-SaaS 数据点

- 浏览器插件：100-2000用户，月收入 $200-5000
- ChatGPT 插件：50-500付费用户，月收入 $100-10000
- 中位时间：3-6个月做起来
- 月入 $1000 以上：约 15-20%
- 月入 $5000 以上：约 3-5%

---

## 收入阶段模型（参考）

| 阶段 | 月收入 | 所需时间 | 占比 |
|------|--------|---------|------|
| 底层 | $0-500 | — | 60% |
| 中层 | $500-3000 | 1-3个月 | 25% |
| 上层 | $3000-10000 | 6-12个月 | 10% |
| 顶层 | $10000+ | 12-18个月 | 5% |

---

## 研究工具使用记录

### 可用的工具
```python
# Wikipedia（稳定）
import urllib.request
url = "https://en.wikipedia.org/api/rest_v1/page/summary/<term>"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})

# HN Algolia（稳定）
url = "https://hn.algolia.com/api/v1/search?query=<query>&tags=story&hitsPerPage=10"

# 失败的工具
# Gumroad API：需要认证token
# ProductHunt API：返回403
```

---

## 下一步研究建议

1. **Run 3（最新AI工具）**：搜索 Claude extensions、Cursor AI、Manus、GPT Agent 相关变现案例
2. **Run 5（中文平台）**：深度研究小红书/抖音/知乎的具体算法和变现路径
3. **Run 6（Micro-SaaS）**：找具体成功案例和 launch 策略

---

## Run 3 研究：B2B AI 销售（2024-2025）

### 核心发现

**企业买 AI 的动因（按频率排序）：**
1. 上级压力/董事会要求
2. 竞争对手已经使用
3. 真实成本压力（裁员成本 > AI 成本）
4. 员工期望（工具现代化需求）

**决策链关键人物：**
- 有预算的业务负责人（VP/总监）> 技术负责人 > C-level

### B2B AI 销售报价公式

```
客户年节省价值 × 0.2-0.3 = 年费报价

例：AI 方案每月节省 10 万 → 年节省 120 万 → 年费 24-36 万
```

### 常见反对话术破解

| 话术 | 破解方法 |
|------|---------|
| "不准" | 卖节省的时间/人力，不是准确性 |
| "考虑一下" | 制造紧迫感（竞品/政策/季节） |
| "太贵" | 改付款结构（分期/按效果） |
| "有现成方案" | 找弱点（效率低/不定制/成本高） |
| "要IT评估" | 找业务部门，不找IT部门下单 |

### B2B 提案结构（5页）

1. 痛点（解决了什么问题）
2. 案例+数据（别人怎么用的）
3. 产品（你的方案是什么）
4. ROI+计划（多少钱+多久见效）
5. 下一步（怎么开始）

附：一页 executive summary（C-level）

### 付款结构创新

- 基础版：5-10万/年（标准化功能）
- 高级版：20-50万/年（定制+效果分成）
- 试用策略：1个月免费 → 按效果签年框
- 效果分成：8-10% 奖金（成单率提升部分的奖金）