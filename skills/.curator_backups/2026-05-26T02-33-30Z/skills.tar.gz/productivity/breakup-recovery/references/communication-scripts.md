## Communication Scripts — How to Say the Hard Things

> *The right words at the right moment can prevent hours of regret. These are maps for when you don't know what to say — not scripts for performance, but guides for honesty.*

Every script here is designed to be: clear (no false hope), honest (no character assassination), and self-respecting (no begging). The goal is to say what is true and necessary — nothing added to cushion, nothing withheld out of cruelty.

### How to Initiate a Breakup (If You Are the One Ending It)

The structure that works:
1. **State the decision** — not "I think," but "I have decided"
2. **Give one honest reason** — not a list of faults, not twenty reasons
3. **Close the door** — no "maybe in the future" unless you genuinely mean it

**Key phrases:**
> "I've decided that this relationship isn't working for me anymore. I need to end it."
>
> "I don't want to hurt you by giving you hope that isn't real. I'm ending this."
>
> "This is not a negotiation. I know that's hard to hear. I'm sorry."

**If you were the dumper and feel guilty:** Guilt is appropriate — it means you have a conscience. Let it motivate you to be as clean as possible in the breakup, not to stay in a relationship you don't want. You do not owe someone a relationship because you feel bad about ending one.

### The No-Contact Rule — What It Is and How to Hold It

**The rule:** Do not break no-contact — no matter what they say. "hey" gets no response. An apology gets no response. Even "I can't do this without you" gets no response — because it is intermittent reinforcement, and one response restarts the cycle.

**Why it works:** No-contact is not a strategy to make them miss you. It is the only condition under which your nervous system can complete the attachment cycle. Every time you break it, you restart the withdrawal. The neurochemistry takes approximately 90 days to stabilize.

**Scripts for when they reach out during no-contact:**
- **Neutral ("hey", "how's it going"):** No response. Not coldness — triage.
- **Apology:** No response. A genuine apology respects no-contact; an apology during no-contact is usually an attempt to reopen contact for guilt relief, not repair.
- **Manipulation ("I miss you", "I can't do this without you"):** No response. This is intermittent reinforcement. The reward (relief, contact) is what reinforces the addiction-like bond. Withhold it.
- **Threat or abuse:** Full block. "I will not be in contact with you. Do not message this number again." Then block.
- **Return something:** "You can mail it to me. I won't be coming to pick it up." Minimal contact, boundaries intact.

**The 24-hour rule:** If something feels urgent enough to break no-contact, wait 24 hours. The version of you that received the message in acute pain is not the version who should interpret it. The 24-hour-later version has more stability and can evaluate more accurately.

### "The Why Did You Leave?" Conversation

If they genuinely want to know and you want to answer:

> "The relationship stopped working for me. I don't think either of us did something wrong that we could fix — it just ran its course."
>
> "I realized I was staying out of comfort, not out of wanting this."
>
> "I wasn't happy in ways I couldn't explain, and I tried to get there but couldn't."

**Do not:** List their flaws, use "you" as the subject of every sentence (puts them in defensive mode), or make it sound like a negotiation.

**If you genuinely don't know why:** "I don't have a clear answer and I don't think it would help either of us to invent one." You do not owe them a comprehensive post-mortem.

### "Let's Be Friends" — How to Handle It

**If you want to be friends but need time first:**
> "I think we could be friends eventually, but right now I need space. Not because I'm angry — because I can't actually hear what you're saying without you in my life. Let's revisit in 6 months if this is still what we both want."

**If you don't want to be friends:**
> "I appreciate that you want to stay connected, but I don't think I can do friendship with you. It wouldn't be honest. I need to move on."

This is not cruel — it is clear. Cruel is saying "yes, let's be friends" and never texting them back, which leaves them waiting.

### The "I Want You Back" Message — How to Respond

**Do not respond immediately.** The chemical state you are in when you receive this message is the same state that made you want them in the first place. It is not a reliable state for decision-making.

**Wait 2 weeks.** Then ask: What specifically has changed — not "they've had time to think" but "they've done X that shows real change"? Did they actually change, or did the pain of losing you create temporary motivation? Would you take them back on the same terms, or are you hoping for something different?

**If after 2 weeks you still want to try:**
> "I need to know what specifically is different and what you are actually offering. I can't make a decision based on a feeling."

**If you realize you don't:**
> "I appreciate you reaching out, but I've thought about it and I don't want to go back. I need to move forward."

### Grief Anniversary Urges — When the Date Triggers the Urge to Reach Out

On a breakup anniversary (the day they left, the day of the breakup), you may feel the urge to text. The impulse is the attachment system looking for a way to complete something that doesn't need completion.

**The response:** The date has meaning — it does not require contact. Write in a journal, text a friend, talk to the air. The feeling needs expression, not necessarily a recipient.

**If they text you on the anniversary:** Same rule applies. The date does not change no-contact. If you've been broken up long enough to have genuine friendship availability, evaluate accordingly — but not in the first 90 days.

**What to tell yourself on the day:**
> "This is my nervous system completing an anniversary pattern. It will pass. Reaching out will not complete anything — it will restart the withdrawal cycle."

### The Last Conversation Trap

One of the most common post-breakup regrets is the "one last conversation" — the belief that one more exchange will resolve something unresolvable.

**Why it's a trap:**
1. There is nothing you can say that will change the outcome. The relationship ended. A final conversation does not undo that.
2. The question "why did this happen?" may not have a clean answer. "I may never fully know why" is an acceptable answer.
3. The person who wants the last conversation is usually you, in a specific neurochemical state. That state is not a reliable guide to what you actually need.

The last conversation is not a closing. It is a reopening.

→ Full content: [references/communication-scripts.md](references/communication-scripts.md)

### What to Say When Someone Asks "Are You Okay?"

In the weeks after a breakup, everyone asks this. You are not okay. Here are honest ways to say that:

> "I'm not okay yet, but I'm working on it."
>
> "Honestly, I'm not great. It's that kind of time."
>
> "I appreciate you asking. I'm in it right now."

**What NOT to do:** Say you're fine when you're not, turn every conversation into a detailed account (co-rumination trap), or pretend everything is fine to avoid being a burden. The middle path: acknowledge you're not okay, don't make it the only thing you talk about, and tell people what helps — distraction, company, or solitude.

### Handling Mutual Friends After the Breakup

You cannot control what your ex says to mutual friends, or what mutual friends do with that information. You can control how you respond.

**If the mutual friend is also their close friend:**
> "I know you're in a tough spot. I don't need you to choose sides — I just need you to not relay information between us. If I want to know about their life, I'll find out on my own."

**If a mutual friend keeps bringing up the ex:**
> "I know you're trying to help, but right now I can't hear about them without it setting me back. Let's talk about something else."

**If the ex is badmouthing you:** Do not correct the record. People who spread misinformation reveal themselves; people who hear it draw their own conclusions.

---

### When Your Ex Reaches Out During No-Contact

**Neutral check-in ("Hey, how are you?"):** Do not respond. A neutral message from an ex during no-contact is a test of boundaries. Your silence communicates that you have standards.

**Apology ("I'm sorry"):** No response. A genuine apology respects no-contact; an apology during no-contact is usually guilt relief, not repair.

**Reference to something ("Saw you got that job — congrats"):** One line only: "Thank you." One line, then silence.

**"I miss you" or "I can't do this without you":** This is intermittent reinforcement. No response. If you must: "I hope you're okay. I need to keep moving forward." Then block.

**Cruel or threatening:** "I will not be in contact with you. Do not message this number again." Then full block.

---

### "I Want You Back" — The Response Protocol

**Under 90 days:** No response. This is attachment chemistry, not love. The relationship ended for real reasons.

**90 days to 6 months:** Wait 2 weeks. Then ask: What specifically has changed? Not "they've had time to think" — but "they've done X that shows real behavioral change."

**The one question that cuts through:** "What specifically is different, and what are you actually offering?" If they cannot answer that, the message is about their pain, not about you.

---

### Responding to "I'm Dating Someone New"

This lands hard even if you initiated the breakup. Do not respond to the content. Do not ask questions. If you must respond: "Thanks for letting me know. I wish you well." Then put your phone away. Feel your feelings privately. Their moving on does not mean you failed — it means the relationship ended, as relationships do.
