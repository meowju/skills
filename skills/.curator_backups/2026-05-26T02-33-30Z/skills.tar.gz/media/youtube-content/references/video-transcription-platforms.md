# Video Platform Transcription Reference

## Instagram Reels

Instagram Reels have **no public transcript API**. The only viable path is download + ASR transcription.

### Steps that worked

```bash
# Step 1: Get direct video URL
uv run yt-dlp --get-url "https://www.instagram.com/reel/DX6Rt-6OE6b/"

# Returns two URLs (video + audio track for DASH adaptive stream)
# Ex: .../.../AQNSPQV2pba6yKSaUuPuz8oiZgQ....mp4
#     .../.../AQPp0uhV2YYCC3cb4tX98WxvfzD6ERn....mp4 (audio)
```

Instagram Reels download as DASH adaptive streams (separate video and audio files). `yt-dlp` auto-merges them into a single MP4 when using `-o /tmp/video.mp4`.

```bash
# Step 2: Download (merged MP4)
uv run yt-dlp -o "/tmp/insta_reel.mp4" "https://www.instagram.com/reel/DX6Rt-6OE6b/"

# Note: Instagram Reel URLs contain a tracking param: ?igsh=MW0weXI0ZjlteWthZg==
# yt-dlp handles this fine — no need to strip it, but also safe to strip.
# Typical file size: ~9-10MB per minute of video.
```

```bash
# Step 3: Extract audio (16kHz mono WAV — what faster-whisper expects)
ffmpeg -i /tmp/insta_reel.mp4 -vn -acodec pcm_s16le -ar 16000 -ac 1 /tmp/insta_audio.wav

# Duration 1:53 → 3.5MB WAV file at 256kbps
```

```bash
# Step 4: Transcribe with faster-whisper
uv run python3 -c "
from faster_whisper import WhisperModel
model = WhisperModel('base', device='cpu', compute_type='int8')
segments, info = model.transcribe('/tmp/insta_audio.wav', language='zh', beam_size=5)
for s in segments:
    print(s.text)
"
```

**Settings used:**
- Model: `base` (fastest, sufficient for clean narration audio)
- `compute_type='int8'` — works on CPU without GPU
- `beam_size=5` — good accuracy/speed tradeoff for ASR
- `language='zh'` — always specify language explicitly for non-English

**Result quality:** The transcription was largely readable from a Chinese-language AI news Reel. Some words were garbled (e.g., brand names like "Adobe" → "阿兜比", "Meta" → "媒卡"), but the overall structure and all 10 news items came through clearly.

### What to try if transcription is poor

1. Try `medium` model instead of `base` — better accuracy for names/proper nouns
2. Try `large` model if `medium` still garbles brand names
3. If Whisper confuses similar-sounding words, a larger model + explicit language helps

## TikTok

Same approach as Instagram Reels — no transcript API, use `yt-dlp` + `faster-whisper`.

## YouTube

Use Path 1 (native transcript API via `youtube-transcript-api`) first. Only fall back to download+whisper if:
- The video has transcripts disabled
- The transcript is available but corrupted/missing sections
- The user wants auto-generated captions which may differ from official subtitles