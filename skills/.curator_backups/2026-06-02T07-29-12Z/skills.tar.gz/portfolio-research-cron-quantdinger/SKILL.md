---
name: portfolio-research-cron-quantdinger
description: 15-min cron job — fetch AI/infra stock signals from QuantDinger, compute indicators with AgenticTendies, write markdown report, deliver via final response.
---

# Portfolio Research Cron (QuantDinger + AgenticTendies)

Runs every 15 min. Delivers the report as the model's final response (cron
delivery is automatic — do NOT call `send_message` tool; it is unavailable
in cron context).

## Environment

- **QuantDinger API**: `http://localhost:8888` (env: `QUANTDINGER_BASE`, `QUANTDINGER_TOKEN`)
- **AgenticTendies venv**: `/opt/data/agentictendies/.venv/bin/python` (has pandas/numpy)
- **Hermes CLI venv**: `/opt/hermes/.venv/bin/python` (has pyyaml — needed for `hermes` CLI)
- **Output dir**: `~/.cron/output/f2f177230acb/`
- **Ticker list**: VRT, SMCI, PLTR, AMD, NVDA, COIN, DELL (AI/infra theme)
- **Portfolio**: TD Direct 41HHH9A — GLD (4 @ $588.79), TSM (5 @ $563.93)

## QuantDinger API (Python urllib — NOT curl)

All responses wrapped in `{code, message, data}`. **Always unwrap with
`resp["data"]` before parsing.**

### Endpoints
- `GET /api/agent/v1/markets` → `{data: [{value, label}, ...]}` — markets are
  `USStock`, `HKStock`, `Crypto`, `Forex`, `Futures`, `MOEX`. **No VIX/S&P
  index market** — VIX requests always return `price: null`.
- `GET /api/agent/v1/price?market=USStock&symbol=XYZ` → `{data: {price: <f|null>}}`
  — **price is often `null`**; use the last kline close instead.
- `GET /api/agent/v1/klines?market=USStock&symbol=XYZ&timeframe=1d&limit=200`
  → `{data: {count, klines: [{time, open, high, low, close, volume}, ...]}}`
  — Returns up to 136 daily bars (~6 months). `time` is unix seconds.

### Auth header
```python
req.add_header("Authorization", f"Bearer {TOKEN}")
```

## Indicator math

Use `agentictendies.core.indicators` (single source of truth):
- `calculate_rsi(prices, 14)` — EMA-smoothed (RMA)
- `calculate_sma(prices, 20|50)` — simple
- `calculate_atr(high, low, close, 14)` — simple rolling mean of true range
- `calculate_ema(prices, span)` — `adjust=False`
- Stochastic %K: 14-period lookback, 3-period SMA of fast %K

**All four indicator functions REQUIRE pandas Series input, not Python lists.**
Passing a list raises `AttributeError: 'list' object has no attribute 'diff'`
(RSI) or `The truth value of a Series is ambiguous` (NaN checks). Convert
kline arrays with `pd.Series([k["close"] for k in klines])` before calling.
Helper: `last_valid(s)` must handle `Series` and `NaN` (see
`scripts/run_research.py` for a working implementation).

## Signal logic (in priority order)
1. RSI < 40 → 🟢 BUY (oversold)
2. RSI > 70 → 🔴 SELL (overbought)
3. RSI 40-55 AND price > SMA20 → 🟢 BUY
4. SMA20 > SMA50 → ⭐ GOLDEN CROSS (trend)
5. Otherwise → 🟡 HOLD

## Confidence score
```
score = min(|RSI - 50|, 30)            # RSI distance, capped
      + |(SMA20-SMA50)/SMA50| * 100 * 1.5   # trend strength %
      + 10 if BUY else 8 if SELL else 0
      + 5 if Stoch > 80 or Stoch < 20
```

## Per-ticker commentary — ALWAYS build dynamically

**Never hardcode a `NOTES = {"DELL": "..."}` dict** — QuantDinger klines
are a static snapshot, not live, so any canned day%/price/RSI string will
be wrong on most runs and mislead the user. (A previous version had
"SMCI +11.6% 涨幅过大" hardcoded; in this run SMCI was +2.66%, which
contradicted the note.)

The `scripts/run_research.py` helper `note_for(r)` builds Chinese
commentary from the freshly-computed `r` dict (RSI, stoch, day%, vol
ratio, SMA20 vs SMA50). If you need additional per-ticker context,
extend `note_for()` to read from `r` — do NOT reintroduce a static
NOTES dict. Same rule applies to the "整体趋势" line in the market
context block: build it from `results["SPY"]["rsi"]` / `sma20` / `sma50`.

## Report template (Chinese commentary + English data)
- Title: `# 📊 AI/基建股票扫描 — YYYY-MM-DD HH:MM`
- Ranking table (10 columns: rank, ticker, price, day%, RSI, SMA20, SMA50,
  StochK, VolRatio, signal, score)
- Portfolio table with live prices + P&L
- Market context: SPY price, SMA50, regime (BULL if price>SMA50, else BEAR).
  VIX marked N/A (not available on QuantDinger). Overall-trend line built
  from SPY RSI, not hardcoded text.
- Per-ticker commentary (one line each, via `note_for(r)`)
- Risk bullets (overbought/oversold/uptrend lists built dynamically)
- Footer with run timestamp + path

## Cron delivery
The model final response IS the delivery. Do not call `send_message` tool —
it is only available in active chat sessions, not in cron. Save the report
file and the `portfolio-research-latest.md` mirror, then return the full
report text as the final response.

## Run command

The full pipeline lives at `scripts/run_research.py` (a working
implementation — copy or invoke directly):

```bash
cd /opt/data/agentictendies && \
  PYTHONPATH=/opt/data/agentictendies \
  .venv/bin/python /opt/data/skills/portfolio-research-cron-quantdinger/scripts/run_research.py
```

This script handles kline fetch, indicator math, signal logic, markdown
assembly, and file output in one shot. The final response from the model
just needs to be the markdown it prints.

## Pitfalls
- **VIX unavailable** — don't loop trying markets, just mark N/A
- **`price` endpoint often null** — always fall back to last kline close
- **Klines default limit is small** — request `limit=200` to get ~136 daily
  bars (enough for SMA50)
- **DO NOT call `hermes send_message` CLI** — it doesn't exist; the
  `hermes` CLI in /opt/hermes needs the /opt/hermes/.venv (pyyaml) but
  lacks a send_message subcommand anyway
- **Indicator functions need pandas Series, not lists** — convert kline
  arrays with `pd.Series(...)` before calling; helper `last_valid` must
  handle Series + NaN
- **`execute_code` sandbox has NO numpy/pandas** — only basic `os`/`json`/
  `urllib`. Compute indicators via the venv: `cd /opt/data/agentictendies
  && PYTHONPATH=/opt/data/agentictendies .venv/bin/python script.py`.
  For one-off runs, write a temp script and exec via `terminal`. Do NOT
  try to import agentictendies inside `execute_code`.
- **QuantDinger klines dataset is a fixed snapshot, not live** — confirmed
  in 2026-06-01 11:20 run: DELL shows +32.76% single-day move, AMD=$516,
  NVDA=$211; the previous 11:07 run produced identical-shape data. Treat
  the report as "same-day close snapshot derived from a static
  back-history," not real-time tickers. Always caveat in commentary when
  day% > 10% or when a ticker's price diverges sharply from real-world
  quotes (DELL+32% / SMCI+11% in one session = data anomaly, not signal).
- **`agentictendies` package import pulls `yfinance`** — even if you only
  want `core.indicators`, importing `from agentictendies.core.indicators`
  triggers `core/__init__.py` → `ingestion.py` → `import yfinance`. This
  is fine in the venv (yfinance is installed there) but the cascade means
  the venv python is required, not bare system python.
- **Never hardcode per-ticker commentary** — QuantDinger klines are a
  static snapshot, not live, so any canned day%/price/RSI string (e.g.
  "DELL +32.76% 异常涨幅") will be wrong on most runs and mislead the
  user. The `run_research.py` script builds per-ticker notes dynamically
  from the freshly-computed `r` dict via `note_for(r)`. If you need to
  add per-ticker context, extend `note_for()` to read from `r` — do
  NOT reintroduce a `NOTES = {"DELL": "..."}` dict. See the
  "Per-ticker commentary — ALWAYS build dynamically" section above.
- **Same applies to the "整体趋势" line in market context** — build it
  from SPY's current RSI/SMA20/SMA50 in `results["SPY"]`, never hardcode
  "科技板块动能强劲" type text.
- **Avoid `datetime.utcnow()`** — deprecated in Python 3.12+, replaced by
  `datetime.now(timezone.utc)`. The script uses the latter.
