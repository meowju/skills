# QuantDinger API — concrete shapes & pitfalls

Local QuantDinger server, base `http://localhost:8888`, bearer token from
`$QUANTDINGER_TOKEN`. Used by multiple cron jobs (portfolio research, market
scans) so this is the canonical reference for the shape of responses.

## Auth header (required)

```python
req.add_header("Authorization", f"Bearer {TOKEN}")
```

`code != 0` means failure even when the HTTP status is 200.

## `GET /api/agent/v1/markets`

Returns the list of available market codes (USStock, HKStock, Crypto, Forex,
Futures, MOEX). Use this to confirm a market is available before requesting
prices for a ticker.

## `GET /api/agent/v1/price?market=USStock&symbol=VRT`

Returns the current price quote. `data` is a single dict, not a list.

**Watch out: `price` can be `null` even on success.** Some tickers the
server doesn't have live data for (observed: `GLD`, `TSM`, possibly more
ETFs/ADRs) come back with `code: 0`, `message: "ok"`, but
`data.price: null`. The `USETF` market code does **not** help — same null.
Always check `d["data"]["price"]` for `None` before using it, and have a
fallback data source (yfinance is the standard one in cron scripts) wired
up at the same time. The typical buggy script wraps the request in
`try/except: return None` which silently swallows the empty result and
never falls through.

## `GET /api/agent/v1/klines?market=USStock&symbol=VRT&timeframe=1d&limit=N`

**THE PITFALL: `limit` is capped.**

- `limit=60` returns **~41** candles, **not** 60. The server caps based on
  the data window it has loaded, not on the requested limit.
- `limit=200` returns **~136** candles — enough for SMA(50), SMA(100),
  walk-forward, etc.

**Always request `limit=200` (or higher)** when you need ≥50 periods for
moving averages, walk-forward splits, or proper RSI/RSI-divergence
analysis. If you only see ~40 candles back, your SMA50 will silently be
`None` and your "golden cross" signal will never fire.

### Response shape

`data` is a **dict** wrapping the actual candles, not a list:

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "market": "USStock",
    "symbol": "VRT",
    "timeframe": "1d",
    "count": 109,
    "klines": [
      {
        "time": 1775016000,   // unix seconds
        "open": 257.0,
        "high": 265.55,
        "low": 257.0,
        "close": 259.37,
        "volume": 5112600.0
      },
      ...
    ]
  }
}
```

### Parser pattern (handles both shapes)

```python
data = resp.get("data")
if isinstance(data, dict):
    raw = data.get("klines") or []
else:
    raw = data or []

candles = []
for k in raw:
    candles.append({
        "t": k.get("time") or k.get("t") or k.get("timestamp"),
        "o": float(k.get("open",  k.get("o", 0))),
        "h": float(k.get("high",  k.get("h", 0))),
        "l": float(k.get("low",   k.get("l", 0))),
        "c": float(k.get("close", k.get("c", 0))),
        "v": float(k.get("volume",k.get("v", 0))),
    })
candles.sort(key=lambda x: x["t"] or 0)  # chronological
```

The field-name fallback (`time` ↔ `t`) covers the case where a future
version of the API collapses to short names.

## Field naming in returned candles

Full names: `time / open / high / low / close / volume`. **Not** the
short `t/o/h/l/c/v` form shown in some docs. Values are floats, including
volume.

## Time field

Unix seconds (not milliseconds). 10-digit timestamps as of 2026.

## Verifying the shape once

```bash
curl -s "http://localhost:8888/api/agent/v1/klines?market=USStock&symbol=VRT&timeframe=1d&limit=200" \
  -H "Authorization: Bearer $QUANTDINGER_TOKEN" | python -c "
import sys, json
d = json.loads(sys.stdin.read())
print('code:', d.get('code'))
data = d.get('data') or {}
print('count:', data.get('count'))
print('keys:', list(data.keys()))
print('first kline keys:', list(data.get('klines', [{}])[0].keys()) if data.get('klines') else 'empty')"
```

If you see `'klines'` is missing from `data`, the API version has changed
and you need to probe again.
